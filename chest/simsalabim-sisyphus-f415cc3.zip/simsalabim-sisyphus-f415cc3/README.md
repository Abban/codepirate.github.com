# Sisyphus
Plugin developed to save html forms data to LocalStorage to restore them after browser crashes, tabs closings and other disasters.

Description and sample are available at http://simsalabim.github.com/sisyphus/

Author: Alexander Kaupanin <kaupanin@gmail.com>